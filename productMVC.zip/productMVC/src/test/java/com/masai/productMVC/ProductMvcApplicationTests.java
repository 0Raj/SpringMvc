package com.masai.productMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
